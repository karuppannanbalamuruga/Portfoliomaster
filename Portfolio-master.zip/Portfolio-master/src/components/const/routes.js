export const ROUTES={
    DASHBOARD : '/',
    PROJECT : 'Project',
    ACADEMYBLOG: 'AcademyBlog',
    CONTACT :'Contact',
};