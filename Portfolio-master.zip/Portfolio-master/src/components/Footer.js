import React from 'react'
import Footercomponent from './Home/Footercomponent';


const Footer = () => {
  return (
    <Footercomponent />
  )
}

export default Footer
