import React from 'react'
import Navcomponent from './Home/Navcomponent'

const Header = () => {
  return (
    <Navcomponent />
  )
}

export default Header
